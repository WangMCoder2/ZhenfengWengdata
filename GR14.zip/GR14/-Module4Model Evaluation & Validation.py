import numpy as np
import pandas as pd
import time
import random
from typing import List, Dict, Tuple, Optional
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
import shap
from concurrent.futures import ThreadPoolExecutor


# -------------------------- Evaluation Metrics Calculation --------------------------
class EvaluationMetrics:
    """
    Compute evaluation metrics for cognitive state prediction (Section4.2).
    Includes classification metrics (accuracy, F1, AUC) and interpretability (SHAP values).
    """

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold  # Threshold for binary classification (0/1)

    def binary_classify(self, predictions: np.ndarray) -> np.ndarray:
        """Convert continuous predictions to binary (0/1) using threshold."""
        return (predictions >= self.threshold).astype(int)

    def compute_classification_metrics(self, y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """Compute classification metrics for a single cognitive state."""
        if len(np.unique(y_true)) < 2:
            # Handle cases with only one class (avoid division by zero)
            return {
                'accuracy': accuracy_score(y_true, y_pred),
                'precision': 0.0,
                'recall': 0.0,
                'f1': 0.0,
                'auc': 0.0
            }
        return {
            'accuracy': round(accuracy_score(y_true, y_pred), 4),
            'precision': round(precision_score(y_true, y_pred, average='weighted'), 4),
            'recall': round(recall_score(y_true, y_pred, average='weighted'), 4),
            'f1': round(f1_score(y_true, y_pred, average='weighted'), 4),
            'auc': round(roc_auc_score(y_true, y_pred), 4) if len(np.unique(y_true)) >= 2 else0.0
        }

    def compute_multi_state_metrics(self, true_states: Dict[str, np.ndarray], pred_states: Dict[str, np.ndarray]) -> \
    Dict[str, Dict[str, float]]:
        """Compute metrics for all three cognitive states (knowledge, value, thinking)."""
        metrics = {}
        for state in ['knowledge', 'value', 'thinking']:
            y_true = self.binary_classify(true_states[state])
            y_pred = self.binary_classify(pred_states[state])
            metrics[state] = self.compute_classification_metrics(y_true, y_pred)
        return metrics

    def compute_confusion_matrix(self, y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
        """Compute confusion matrix for a single state."""
        return confusion_matrix(y_true, y_pred)

    def compute_shap_values(self, model: object, X: np.ndarray) -> np.ndarray:
        """Compute SHAP values for model interpretability (Section4.2)."""
        # Mock SHAP values (or use real SHAP library for actual models)
        explainer = shap.Explainer(model.predict, X)
        shap_values = explainer(X)
        return shap_values.values

    def summarize_shap_values(self, shap_values: np.ndarray) -> Dict[str, float]:
        """Summarize SHAP values to get feature importance."""
        feature_importance = np.mean(np.abs(shap_values), axis=0)
        return {f'feature_{i}': round(imp, 4) for i, imp in enumerate(feature_importance)}


# -------------------------- Ablation Study --------------------------
class AblationStudy:
    """
    Conduct ablation study to evaluate component impact (Section4.3).
    Tests the effect of removing key components: gated attention, dynamic fusion, TCN-GRU alignment.
    """

    def __init__(self, full_model: object, data_loader: object):
        self.full_model = full_model
        self.data_loader = data_loader
        self.components = ['gated_attention', 'dynamic_fusion', 'tcn_gru_alignment']

    def remove_component(self, component: str) -> object:
        """Remove a component from the full model to create an ablation variant."""
        if component == 'gated_attention':
            # Create model without gated attention (use simple concatenation)
            class AblationModelNoGatedAttention:
                def __init__(self, base_model):
                    self.base_model = base_model

                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Skip gated attention: concatenate aligned features directly
                    aligned_behavior, aligned_text = self.base_model.feature_aligner.align_features(X_behavior, X_text)
                    fused_feat = np.concatenate([aligned_behavior, aligned_text], axis=0)
                    return self.base_model.predictor.predict(fused_feat)

            return AblationModelNoGatedAttention(self.full_model)

        elif component == 'dynamic_fusion':
            # Create model without dynamic fusion (use static weighted average)
            class AblationModelNoDynamicFusion:
                def __init__(self, base_model):
                    self.base_model = base_model
                    self.weight_behavior = 0.5
                    self.weight_text = 0.5

                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    aligned_behavior, aligned_text = self.base_model.feature_aligner.align_features(X_behavior, X_text)
                    attended_behavior, attended_text, _ = self.base_model.gated_attention.forward(aligned_behavior,
                                                                                                  aligned_text)
                    # Static weighted average instead of dynamic fusion
                    fused_feat = self.weight_behavior * attended_behavior + self.weight_text * attended_text
                    return self.base_model.predictor.predict(fused_feat)

            return AblationModelNoDynamicFusion(self.full_model)

        elif component == 'tcn_gru_alignment':
            # Create model without TCN-GRU alignment (use raw features)
            class AblationModelNoAlignment:
                def __init__(self, base_model):
                    self.base_model = base_model

                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Skip alignment: use mean of raw features
                    raw_behavior = np.mean(X_behavior, axis=0)
                    raw_text = np.mean(X_text, axis=0)
                    attended_behavior, attended_text, _ = self.base_model.gated_attention.forward(raw_behavior,
                                                                                                  raw_text)
                    fused_feat = self.base_model.fusion_module.fuse_features(attended_behavior, attended_text)
                    return self.base_model.predictor.predict(fused_feat)

            return AblationModelNoAlignment(self.full_model)

        else:
            raise ValueError(f"Unknown component: {component}")

    def run_ablation(self) -> Dict[str, Dict[str, float]]:
        """Run ablation study for all components and return results."""
        results = {}
        # Full model results
        X_behavior, X_text, y_true = self.data_loader.load_test_data()
        y_pred_full = self.full_model.process_modalities(X_behavior, X_text)
        metrics_full = EvaluationMetrics().compute_multi_state_metrics(y_true, y_pred_full)
        results['full_model'] = metrics_full

        # Ablation for each component
        for component in self.components:
            ablation_model = self.remove_component(component)
            y_pred_ablation = ablation_model.predict(X_behavior, X_text)
            metrics_ablation = EvaluationMetrics().compute_multi_state_metrics(y_true, y_pred_ablation)
            results[f'without_{component}'] = metrics_ablation

        return results


# -------------------------- Cross-Course Validation --------------------------
class CrossCourseValidator:
    """
    Conduct cross-course validation to test model generalization (Section4.4).
    Trains on one course and tests on another.
    """

    def __init__(self, model: object, data_loader: object):
        self.model = model
        self.data_loader = data_loader
        self.courses = ['Marxist Principles', 'Socialism with Chinese Characteristics', 'Ideology and Morality',
                        'Legal Basis', 'Situation and Policy']

    def cross_validate(self) -> Dict[str, Dict[str, float]]:
        """Run cross-course validation for all course pairs."""
        results = {}
        for train_course in self.courses:
            for test_course in self.courses:
                if train_course == test_course:
                    continue
                # Load train and test data
                X_train_behavior, X_train_text, y_train = self.data_loader.load_course_data(train_course)
                X_test_behavior, X_test_text, y_test = self.data_loader.load_course_data(test_course)

                # Train model (mock training for simulation)
                self.model.train(X_train_behavior, X_train_text, y_train)

                # Test model
                y_pred = self.model.process_modalities(X_test_behavior, X_test_text)

                # Compute metrics
                metrics = EvaluationMetrics().compute_multi_state_metrics(y_test, y_pred)
                results[f'{train_course}_to_{test_course}'] = metrics

        return results

    def summarize_cross_course_results(self, results: Dict[str, Dict[str, float]]) -> Dict[str, float]:
        """Summarize cross-course results to get average accuracy per course."""
        avg_accuracy = {}
        for course in self.courses:
            course_results = [res['value']['accuracy'] for key, res in results.items() if
                              course in key.split('_to_')[1]]
            avg_accuracy[course] = round(np.mean(course_results), 4) if course_results
            else0
            .0
        return avg_accuracy


# -------------------------- Baseline Model Comparison --------------------------
class BaselineComparer:
    """
    Compare proposed model with baseline models (Section4.4).
    Baselines: LSTM-only, BERT-only, Early Fusion, ResNet-LSTM, Transformer.
    """

    def __init__(self, proposed_model: object, data_loader: object):
        self.proposed_model = proposed_model
        self.data_loader = data_loader
        self.baselines = ['lstm_only', 'bert_only', 'early_fusion', 'resnet_lstm', 'transformer']

    def load_baseline_model(self, baseline_name: str) -> object:
        """Load baseline model (mock implementations)."""
        if baseline_name == 'lstm_only':
            class LSTMOnlyModel:
                def predict(self, X_behavior: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Mock prediction using only behavior features
                    avg_behavior = np.mean(X_behavior, axis=0)
                    knowledge = sigmoid(np.dot(avg_behavior, np.random.randn(32)) + 0.5)
                    value = sigmoid(np.dot(avg_behavior, np.random.randn(32)) + 0.5)
                    thinking = sigmoid(np.dot(avg_behavior, np.random.randn(32)) + 0.5)
                    return knowledge, value, thinking

            return LSTMOnlyModel()

        elif baseline_name == 'bert_only':
            class BERTOnlyModel:
                def predict(self, X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Mock prediction using only text features
                    avg_text = np.mean(X_text, axis=0)
                    knowledge = sigmoid(np.dot(avg_text, np.random.randn(32)) + 0.5)
                    value = sigmoid(np.dot(avg_text, np.random.randn(32)) + 0.5)
                    thinking = sigmoid(np.dot(avg_text, np.random.randn(32)) + 0.5)
                    return knowledge, value, thinking

            return BERTOnlyModel()

        elif baseline_name == 'early_fusion':
            class EarlyFusionModel:
                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Mock early fusion (concatenate raw features)
                    avg_behavior = np.mean(X_behavior, axis=0)
                    avg_text = np.mean(X_text, axis=0)
                    fused = np.concatenate([avg_behavior, avg_text])
                    knowledge = sigmoid(np.dot(fused, np.random.randn(64)) + 0.5)
                    value = sigmoid(np.dot(fused, np.random.randn(64)) + 0.5)
                    thinking = sigmoid(np.dot(fused, np.random.randn(64)) + 0.5)
                    return knowledge, value, thinking

            return EarlyFusionModel()

        elif baseline_name == 'resnet_lstm':
            class ResNetLSTMModel:
                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Mock ResNet-LSTM fusion
                    behavior_feat = np.mean(X_behavior, axis=0)
                    text_feat = np.mean(X_text, axis=0)
                    fused = behavior_feat * 0.6 + text_feat * 0.4
                    knowledge = sigmoid(np.dot(fused, np.random.randn(32)) + 0.5)
                    value = sigmoid(np.dot(fused, np.random.randn(32)) + 0.5)
                    thinking = sigmoid(np.dot(fused, np.random.randn(32)) + 0.5)
                    return knowledge, value, thinking

            return ResNetLSTMModel()

        elif baseline_name == 'transformer':
            class TransformerModel:
                def predict(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> Tuple[float, float, float]:
                    # Mock Transformer fusion
                    behavior_feat = np.mean(X_behavior, axis=0)
                    text_feat = np.mean(X_text, axis=0)
                    fused = np.matmul(behavior_feat, text_feat.T)
                    knowledge = sigmoid(fused + 0.5)
                    value = sigmoid(fused + 0.5)
                    thinking = sigmoid(fused + 0.5)
                    return knowledge, value, thinking

            return TransformerModel()

        else:
            raise ValueError(f"Unknown baseline: {baseline_name}")

    def compare_baselines(self) -> Dict[str, Dict[str, float]]:
        """Compare proposed model with all baselines."""
        results = {}
        # Load test data
        X_test_behavior, X_test_text, y_test = self.data_loader.load_test_data()

        # Proposed model results
        y_pred_proposed = self.proposed_model.process_modalities(X_test_behavior, X_test_text)
        metrics_proposed = EvaluationMetrics().compute_multi_state_metrics(y_test, y_pred_proposed)
        results['proposed_model'] = metrics_proposed

        # Baseline results
        for baseline in self.baselines:
            baseline_model = self.load_baseline_model(baseline)
            if baseline == 'lstm_only':
                y_pred = baseline_model.predict(X_test_behavior)
            elif baseline == 'bert_only':
                y_pred = baseline_model.predict(X_test_text)
            else:
                y_pred = baseline_model.predict(X_test_behavior, X_test_text)

            # Convert prediction tuple to dict
            y_pred_dict = {
                'knowledge': np.array([y_pred[0]]),
                'value': np.array([y_pred[1]]),
                'thinking': np.array([y_pred[2]])
            }
            metrics = EvaluationMetrics().compute_multi_state_metrics(y_test, y_pred_dict)
            results[baseline] = metrics

        return results


# -------------------------- Real-Time Performance Testing --------------------------
class RealTimePerformanceTester:
    """
    Test real-time performance of the model (Section4.5).
    Measures latency and throughput under different concurrency levels.
    """

    def __init__(self, model: object, data_loader: object):
        self.model = model
        self.data_loader = data_loader
        self.concurrency_levels = [100, 500, 1000, 2000, 5000]

    def simulate_request(self, X_behavior: List[np.ndarray], X_text: List[np.ndarray]) -> float:
        """Simulate a single request and return latency in milliseconds."""
        start_time = time.time()
        self.model.process_modalities(X_behavior, X_text)
        end_time = time.time()
        latency = (end_time - start_time) * 1000  # Convert to ms
        return latency

    def simulate_concurrent_requests(self, concurrency: int) -> Tuple[float, float]:
        """Simulate concurrent requests and return average latency and throughput."""
        # Load test data
        X_test_behavior, X_test_text, _ = self.data_loader.load_test_data()

        # Simulate concurrent requests using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = []
            for _ in range(concurrency):
                futures.append(executor.submit(self.simulate_request, X_test_behavior, X_test_text))

            # Collect results
            latencies = [future.result() for future in futures]

        # Compute metrics
        avg_latency = np.mean(latencies)
        throughput = concurrency / (sum(latencies) / 1000)  # Requests per second

        return avg_latency, throughput

r
