import numpy as np
import pandas as pd
from typing import List, Tuple, Dict, Optional
from scipy.signal import convolve
from collections import defaultdict


# -------------------------- Feature Alignment Component --------------------------
class TCNGRUFeatureAligner:
    """
    Temporal Convolutional Network (TCN) + GRU for feature alignment (Section3.4).
    Aligns asynchronous behavior and text features using temporal modeling.
    """

    def __init__(self, behavior_feature_dim: int = 32, text_feature_dim: int = 32,
                 tcn_filters: int = 16, gru_units: int = 16, kernel_size: int = 3):
        """
        Args:
            behavior_feature_dim: Dimension of behavior features (from Module1)
            text_feature_dim: Dimension of text features (from Module2)
            tcn_filters: Number of TCN filters for behavior sequence
            gru_units: Number of GRU units for text sequence
            kernel_size: TCN kernel size
        """
        self.behavior_dim = behavior_feature_dim
        self.text_dim = text_feature_dim
        self.tcn_filters = tcn_filters
        self.gru_units = gru_units
        self.kernel_size = kernel_size

        # Mock TCN weights
        self.tcn_weights = np.random.randn(kernel_size, behavior_feature_dim, tcn_filters) * 0.01
        self.tcn_bias = np.random.randn(tcn_filters) * 0.01

        # Mock GRU weights (update, reset, hidden gates)
        self.gru_update_weights = np.random.randn(text_feature_dim + gru_units, gru_units) * 0.01
        self.gru_reset_weights = np.random.randn(text_feature_dim + gru_units, gru_units) * 0.01
        self.gru_hidden_weights = np.random.randn(text_feature_dim + gru_units, gru_units) * 0.01
        self.gru_bias = np.random.randn(gru_units) * 0.01

    def tcn_forward(self, behavior_seq: np.ndarray) -> np.ndarray:
        """TCN forward pass for behavior sequence alignment."""
        seq_len, feat_dim = behavior_seq.shape
        if seq_len < self.kernel_size:
            # Pad sequence if shorter than kernel size
            pad_len = self.kernel_size - seq_len
            behavior_seq = np.pad(behavior_seq, ((pad_len // 2, pad_len - pad_len // 2), (0, 0)), mode='constant')
            seq_len = behavior_seq.shape[0]

        # Apply TCN convolution
        conv_out = np.zeros((seq_len - self.kernel_size + 1, self.tcn_filters))
        for i in range(seq_len - self.kernel_size + 1):
            window = behavior_seq[i:i + self.kernel_size]
            conv_out[i] = np.sum(window[:, :, np.newaxis] * self.tcn_weights, axis=(0, 1)) + self.tcn_bias

        # ReLU activation
        conv_out = np.maximum(conv_out, 0)
        # Mean pooling to fixed dimension
        return np.mean(conv_out, axis=0)

    def gru_forward(self, text_seq: np.ndarray) -> np.ndarray:
        """GRU forward pass for text sequence alignment."""
        seq_len, feat_dim = text_seq.shape
        hidden_state = np.zeros((1, self.gru_units))

        for i in range(seq_len):
            text_feat = text_seq[i].reshape(1, -1)
            # Concatenate text feature and hidden state
            concat = np.concatenate([text_feat, hidden_state], axis=1)
            # Update gate
            update_gate = sigmoid(concat @ self.gru_update_weights + self.gru_bias)
            # Reset gate
            reset_gate = sigmoid(concat @ self.gru_reset_weights + self.gru_bias)
            # New hidden state
            new_hidden = np.tanh(concat @ self.gru_hidden_weights + reset_gate * hidden_state + self.gru_bias)
            # Update hidden state
            hidden_state = update_gate * hidden_state + (1 - update_gate) * new_hidden

        return hidden_state[0]

    def align_features(self, behavior_features: List[np.ndarray], text_features: List[np.ndarray]) -> Tuple[
        np.ndarray, np.ndarray]:
        """Align behavior and text features using TCN and GRU."""
        # Convert behavior list to sequence (shape: seq_len x feat_dim)
        behavior_seq = np.array(behavior_features)
        # Convert text list to sequence
        text_seq = np.array(text_features)

        # Align behavior
        aligned_behavior = self.tcn_forward(behavior_seq)
        # Align text
        aligned_text = self.gru_forward(text_seq)

        return aligned_behavior, aligned_text


# -------------------------- Bidirectional Gated Attention --------------------------
class BidirectionalGatedAttention:
    """
    Bidirectional gated attention for cross-modal interaction (Section3.4).
    Computes attention weights between behavior and text features, then applies gates.
    """

    def __init__(self, behavior_dim: int, text_dim: int, hidden_dim: int = 64):
        self.behavior_dim = behavior_dim
        self.text_dim = text_dim
        self.hidden_dim = hidden_dim

        # Attention weights
        self.behavior_attn_weights = np.random.randn(behavior_dim, hidden_dim) * 0.01
        self.text_attn_weights = np.random.randn(text_dim, hidden_dim) * 0.01
        self.attn_bias = np.random.randn(hidden_dim) * 0.01

        # Gate weights
        self.behavior_gate_weights = np.random.randn(hidden_dim, behavior_dim) * 0.01
        self.text_gate_weights = np.random.randn(hidden_dim, text_dim) * 0.01
        self.gate_bias = np.random.randn(1) * 0.01

    def compute_attention(self, behavior_feat: np.ndarray, text_feat: np.ndarray) -> np.ndarray:
        """Compute cross-modal attention scores."""
        # Project behavior and text to hidden space
        behavior_proj = behavior_feat @ self.behavior_attn_weights
        text_proj = text_feat @ self.text_attn_weights
        # Compute attention score (dot product)
        attn_score = np.dot(behavior_proj, text_proj.T) + self.attn_bias
        # Softmax to get weights
        return softmax(attn_score)

    def apply_gate(self, feat: np.ndarray, gate_weights: np.ndarray, attn_score: np.ndarray) -> np.ndarray:
        """Apply gate to feature using attention score."""
        gate = sigmoid(attn_score @ gate_weights + self.gate_bias)
        return feat * gate

    def forward(self, behavior_feat: np.ndarray, text_feat: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Forward pass: returns attended behavior, attended text, and attention score."""
        # Compute attention
        attn_score = self.compute_attention(behavior_feat, text_feat)
        # Apply gates
        attended_behavior = self.apply_gate(behavior_feat, self.behavior_gate_weights, attn_score)
        attended_text = self.apply_gate(text_feat, self.text_gate_weights, attn_score)

        return attended_behavior, attended_text, attn_score


# -------------------------- Dynamic Fusion Module --------------------------
class DynamicFusionModule:
    """
    Dynamic fusion module with regularization (Section3.4).
    Combines attended behavior and text features with a regularization term to prevent modal collapse.
    """

    def __init__(self, behavior_dim: int, text_dim: int, fused_dim: int = 64, reg_lambda: float = 0.01):
        self.behavior_dim = behavior_dim
        self.text_dim = text_dim
        self.fused_dim = fused_dim
        self.reg_lambda = reg_lambda

        # Fusion weights
        self.fusion_weights = np.random.randn(behavior_dim + text_dim, fused_dim) * 0.01
        self.fusion_bias = np.random.randn(fused_dim) * 0.01

    def fuse_features(self, behavior_feat: np.ndarray, text_feat: np.ndarray) -> np.ndarray:
        """Fuse attended behavior and text features with regularization."""
        # Concatenate features
        concat_feat = np.concatenate([behavior_feat, text_feat], axis=0)
        # Apply linear transformation
        fused_feat = concat_feat @ self.fusion_weights + self.fusion_bias
        # Add regularization term (L2 norm of behavior and text features)
        reg_term = self.reg_lambda * (np.linalg.norm(behavior_feat) + np.linalg.norm(text_feat))
        fused_feat += reg_term
        # ReLU activation
        fused_feat = np.maximum(fused_feat, 0)

        return fused_feat


# -------------------------- Multi-task Cognitive Predictor --------------------------
class MultiTaskCognitivePredictor:
    """
    Multi-task predictor for cognitive states (Section3.4).
    Predicts three cognitive states: knowledge mastery, value recognition, thinking quality.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 32):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim

        # Shared MLP layer
        self.shared_weights = np.random.randn(input_dim, hidden_dim) * 0.01
        self.shared_bias = np.random.randn(hidden_dim) * 0.01

        # Task-specific layers
        # Knowledge mastery
        self.knowledge_weights = np.random.randn(hidden_dim, 1) * 0.01
        self.knowledge_bias = np.random.randn(1) * 0.01
        # Value recognition
        self.value_weights = np.random.randn(hidden_dim, 1) * 0.01
        self.value_bias = np.random.randn(1) * 0.01
        # Thinking quality
        self.thinking_weights = np.random.randn(hidden_dim, 1) * 0.01
        self.thinking_bias = np.random.randn(1) * 0.01

    def predict(self, fused_feat: np.ndarray) -> Tuple[float, float, float]:
        """Predict cognitive states from fused features."""
        # Shared MLP layer
        shared_feat = fused_feat @ self.shared_weights + self.shared_bias
        shared_feat = np.tanh(shared_feat)

        # Knowledge mastery prediction (0-1)
        knowledge = sigmoid(shared_feat @ self.knowledge_weights + self.knowledge_bias)[0]
        # Value recognition prediction (0-1)
        value = sigmoid(shared_feat @ self.value_weights + self.value_bias)[0]
        # Thinking quality prediction (0-1)
        thinking = sigmoid(shared_feat @ self.thinking_weights + self.thinking_bias)[0]

        return knowledge, value, thinking


# -------------------------- Helper Functions --------------------------
def sigmoid(x: np.ndarray) -> np.ndarray:
    """Sigmoid activation function."""
    return 1 / (1 + np.exp(-x))


def softmax(x: np.ndarray) -> np.ndarray:
    """Softmax activation function."""
    exp_x = np.exp(x - np.max(x))
    return exp_x / np.sum(exp_x)


# -------------------------- End-to-End Multi-modal Fusion Pipeline --------------------------
class MultiModalFusionPipeline:
    """
    End-to-end pipeline for multi-modal cognitive prediction (Section3.4).
    Combines behavior processing (Module1), text processing (Module2), and fusion/prediction (Module3).
    """

    def __init__(self, behavior_dim: int = 32, text_dim: int = 32, fused_dim: int = 64):
        # Initialize components
        self.feature_aligner = TCNGRUFeatureAligner(behavior_dim=behavior_dim, text_dim=text_dim)
        self.gated_attention = BidirectionalGatedAttention(behavior_dim=behavior_dim, text_dim=text_dim)
        self.fusion_module = DynamicFusionModule(behavior_dim=behavior_dim, text_dim=text_dim, fused_dim=fused_dim)
        self.predictor = MultiTaskCognitivePredictor(input_dim=fused_dim)

    def process_modalities(self, behavior_features: List[np.ndarray], text_features: List[np.ndarray]) -> Tuple[
        float, float, float, np.ndarray]:
        """Process behavior and text features to predict cognitive states."""
        # Align features
        aligned_behavior, aligned_text = self.feature_aligner.align_features(behavior_features, text_features)
        # Apply gated attention
        attended_behavior, attended_text, attn_score = self.gated_attention.forward(aligned_behavior, aligned_text)
        # Fuse features
        fused_feat = self.fusion_module.fuse_features(attended_behavior, attended_text)
        # Predict cognitive states
        knowledge, value, thinking = self.predictor.predict(fused_feat)

        return knowledge, value, thinking, attn_score


# -------------------------- Example Usage --------------------------
def generate_sample_behavior_features(num_segments: int = 5) -> List[np.ndarray]:
    """Generate sample behavior features (from Module1 output)."""
    behavior_features = []
    for _ in range(num_segments):
        # Mock behavior features (32-dimensional)
        feat = np.random.randn(32) * 0.1 + 0.5
        behavior_features.append(feat)
    return behavior_features


def generate_sample_text_features(num_comments: int = 5) -> List[np.ndarray]:
    """Generate sample text features (from Module2 output)."""
    text_features = []
    for _ in range(num_comments):
        # Mock text features (32-dimensional)
        feat = np.random.randn(32) * 0.1 + 0.5
        text_features.append(feat)
    return text_features


if __name__ == "__main__":
    print("=== Module3: Multi-modal Fusion & Cognitive State Prediction ===")

    # Generate sample data
    behavior_features = generate_sample_behavior_features(num_segments=5)
    text_features = generate_sample_text_features(num_comments=5)
    print(f"Generated {len(behavior_features)} behavior segments and {len(text_features)} text comments.")

    # Initialize pipeline
    pipeline = MultiModalFusionPipeline(behavior_dim=32, text_dim=32, fused_dim=64)

    # Process modalities
    knowledge, value, thinking, attn_score = pipeline.process_modalities(behavior_features, text_features)

    # Print results
    print("\nCognitive State Predictions:")
    print(f"Knowledge Mastery: {knowledge:.4f}")
    print(f"Value Recognition: {value:.4f}")
    print(f"Thinking Quality: {thinking:.4f}")
    print(f"\nAttention Score (Behavior-Text Relevance): {attn_score[0]:.4f}")

    print("\nModule3 Execution Complete")
