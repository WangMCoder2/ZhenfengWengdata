import numpy as np
import pandas as pd
import random
from typing import List, Dict, Tuple, Optional
from scipy.stats import pearsonr
from datetime import datetime


# -------------------------- Cognitive Portrait Generator --------------------------
class CognitivePortraitGenerator:
    """
    Generate cognitive portraits for students based on multi-modal data (Section5).
    Combines cognitive state predictions, feature importance, and behavior-emotion patterns.
    """

    def __init__(self):
        self.portrait_sections = [
            "Basic Information", "Cognitive State Summary",
            "Key Strengths", "Areas for Improvement",
            "Feature Importance (SHAP)", "Behavior-Emotion Patterns"
        ]

    def generate_portrait(self,
                          student_id: str,
                          cognitive_states: Dict[str, float],
                          behavior_features: Dict[str, float],
                          text_features: Dict[str, float],
                          shap_values: Dict[str, float],
                          behavior_emotion_patterns: List[str]
                          ) -> Dict[str, str]:
        """
        Generate a structured cognitive portrait for a student.
        Args:
            student_id: Unique student identifier
            cognitive_states: Dict of cognitive state scores (knowledge, value, thinking)
            behavior_features: Key behavior features (e.g., click frequency, pause count)
            text_features: Key text features (e.g., sentiment score, domain term count)
            shap_values: Feature importance from SHAP analysis
            behavior_emotion_patterns: Correlation patterns (e.g., "High pause count correlates with low sentiment")
        Returns:
            Structured portrait as a dict
        """
        portrait = {}

        # Basic Information
        portrait[
            "Basic Information"] = f"Student ID: {student_id}\nGenerated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        # Cognitive State Summary
        state_summary = []
        for state, score in cognitive_states.items():
            level = self._get_cognitive_level(score)
            state_summary.append(f"{state.replace('_', ' ').title()}: {score:.2f} ({level})")
        portrait["Cognitive State Summary"] = "\n".join(state_summary)

        # Key Strengths
        strengths = []
        # Strengths from cognitive states
        for state, score in cognitive_states.items():
            if score >= 0.7:
                strengths.append(f"Strong {state.replace('_', ' ')} (score: {score:.2f})")
        # Strengths from behavior features
        if behavior_features.get("click_frequency", 0) >= 50:
            strengths.append(f"High engagement (click frequency: {behavior_features['click_frequency']})")
        if text_features.get("sentiment_score", 0) >= 0.5:
            strengths.append(f"Positive emotional engagement (sentiment score: {text_features['sentiment_score']})")
        portrait["Key Strengths"] = "\n".join(strengths) if strengths else "No major strengths identified yet."

        # Areas for Improvement
        improvements = []
        for state, score in cognitive_states.items():
            if score <= 0.3:
                improvements.append(f"Low {state.replace('_', ' ')} (score: {score:.2f})")
        if behavior_features.get("pause_count", 0) >= 10:
            improvements.append(f"Low focus (pause count: {behavior_features['pause_count']})")
        if text_features.get("domain_term_count", 0) <= 2:
            improvements.append(f"Limited use of domain terms (count: {text_features['domain_term_count']})")
        portrait["Areas for Improvement"] = "\n".join(
            improvements) if improvements else "All areas are performing well."

        # Feature Importance (SHAP)
        sorted_shap = sorted(shap_values.items(), key=lambda x: abs(x[1]), reverse=True)[:5]
        shap_summary = [f"{feature}: {value:.2f}" for feature, value in sorted_shap]
        portrait["Feature Importance (SHAP)"] = "\n".join(shap_summary)

        # Behavior-Emotion Patterns
        portrait["Behavior-Emotion Patterns"] = "\n".join(
            behavior_emotion_patterns) if behavior_emotion_patterns else "No significant patterns identified."

        return portrait

    def _get_cognitive_level(self, score: float) -> str:
        """Map cognitive score to level (Low/Medium/High)."""
        if score >= 0.7:
            return "High"
        elif score >= 0.4:
            return "Medium"
        else:
            return "Low"


# -------------------------- Intervention Strategy Engine --------------------------
class InterventionStrategyEngine:
    """
    Generate personalized teaching interventions based on cognitive portraits (Section5).
    Strategies are prioritized based on impact and feasibility.
    """

    def __init__(self):
        self.strategy_templates = {
            "content_recommendation": {
                "type": "Content",
                "priority": "High",
                "impact": "Medium",
                "template": "Recommend {content_type} on {topic} to improve {state}."
            },
            "feedback_session": {
                "type": "Feedback",
                "priority": "High",
                "impact": "High",
                "template": "Schedule a 15-minute feedback session to discuss {area} and provide personalized guidance."
            },
            "activity_suggestion": {
                "type": "Activity",
                "priority": "Medium",
                "impact": "Medium",
                "template": "Suggest {activity_type} activity on {topic} to enhance {state}."
            },
            "peer_collaboration": {
                "type": "Collaboration",
                "priority": "Medium",
                "impact": "Medium",
                "template": "Pair with a peer who excels in {area} for collaborative learning."
            }
        }
        self.content_types = ["video lecture", "case study", "interactive quiz", "reading material"]
        self.activity_types = ["group discussion", "role-play", "debate", "project"]

    def generate_strategies(self, portrait: Dict[str, str]) -> List[Dict[str, str]]:
        """Generate personalized strategies from cognitive portrait."""
        strategies = []

        # Extract key info from portrait
        cognitive_summary = portrait["Cognitive State Summary"]
        improvements = portrait["Areas for Improvement"]
        patterns = portrait["Behavior-Emotion Patterns"]

        # Strategy for low cognitive states
        if "Low knowledge" in cognitive_summary:
            strategy = self._create_strategy(
                template_key="content_recommendation",
                content_type=random.choice(["interactive quiz", "video lecture"]),
                topic="key concepts",
                state="knowledge mastery"
            )
            strategies.append(strategy)

        if "Low value" in cognitive_summary:
            strategy = self._create_strategy(
                template_key="content_recommendation",
                content_type=random.choice(["case study", "reading material"]),
                topic="core socialist values",
                state="value recognition"
            )
            strategies.append(strategy)

        if "Low thinking" in cognitive_summary:
            strategy = self._create_strategy(
                template_key="activity_suggestion",
                activity_type=random.choice(["group discussion", "debate"]),
                topic="critical thinking",
                state="thinking quality"
            )
            strategies.append(strategy)

        # Strategy for areas of improvement
        if "Low focus" in improvements:
            strategy = self._create_strategy(
                template_key="feedback_session",
                area="focus and engagement",
            )
            strategies.append(strategy)

        if "Limited use of domain terms" in improvements:
            strategy = self._create_strategy(
                template_key="content_recommendation",
                content_type="reading material",
                topic="domain terminology",
                state="value recognition"
            )
            strategies.append(strategy)

        # Strategy for behavior-emotion patterns
        if "high pause count correlates with low sentiment" in patterns.lower():
            strategy = self._create_strategy(
                template_key="peer_collaboration",
                area="engagement and sentiment",
            )
            strategies.append(strategy)

        # Prioritize strategies
        strategies = sorted(strategies, key=lambda x: ("High", "Medium", "Low").index(x["priority"]), reverse=True)

        return strategies

    def _create_strategy(self, template_key: str, **kwargs) -> Dict[str, str]:
        """Create a strategy from template and parameters."""
        template = self.strategy_templates[template_key]
        description = template["template"].format(**kwargs)
        return {
            "type": template["type"],
            "description": description,
            "priority": template["priority"],
            "estimated_impact": template["impact"]
        }


# -------------------------- Behavior-Affect Correlation Analyzer --------------------------
class BehaviorAffectCorrelator:
    """
    Analyze correlations between behavior features and emotional states (Section5).
    Computes Pearson correlation coefficients and generates correlation rules.
    """

    def __init__(self):
        self.correlation_threshold = 0.3  # Minimum absolute correlation to consider significant

    def compute_correlations(self, behavior_data: pd.DataFrame, emotion_data: pd.DataFrame) -> Dict[str, float]:
        """Compute Pearson correlations between behavior features and emotion scores."""
        correlations = {}
        # Ensure both dataframes have the same index (student IDs)
        merged_data = pd.merge(behavior_data, emotion_data, left_index=True, right_index=True)

        # Compute correlations for each behavior feature vs emotion score
        for behavior_feature in behavior_data.columns:
            if behavior_feature not in merged_data.columns:
                continue
            for emotion_feature in emotion_data.columns:
                if emotion_feature not in merged_data.columns:
                    continue
                # Compute Pearson correlation
                corr, p_value = pearsonr(merged_data[behavior_feature], merged_data[emotion_feature])
                if abs(corr) >= self.correlation_threshold and p_value < 0.05:
                    correlations[f"{behavior_feature} vs {emotion_feature}"] = {
                        "correlation": corr,
                        "p_value": p_value
                    }

        return correlations

    def generate_correlation_rules(self, correlations: Dict[str, Dict[str, float]]) -> List[str]:
        """Generate human-readable correlation rules from correlation data."""
        rules = []
        for key, value in correlations.items():
            behavior_feature, emotion_feature = key.split(" vs ")
            corr = value["correlation"]
            p_value = value["p_value"]

            # Direction of correlation
            if corr > 0:
                direction = "positive"
            else:
                direction = "negative"

            # Rule description
            rule = f"Significant {direction} correlation between {behavior_feature} and {emotion_feature} (r={corr:.2f}, p={p_value:.3f})"
            # Add interpretation
            if direction == "positive":
                if behavior_feature == "click_frequency" and emotion_feature == "sentiment_score":
                    rule += " → Higher engagement correlates with more positive sentiment."
                elif behavior_feature == "pause_count" and emotion_feature == "sentiment_score":
                    rule += " → Higher pause count correlates with more positive sentiment (unexpected, needs further analysis)."
            else:
                if behavior_feature == "pause_count" and emotion_feature == "sentiment_score":
                    rule += " → Higher pause count correlates with more negative sentiment."
                elif behavior_feature == "download_count" and emotion_feature == "sentiment_score":
                    rule += " → Higher download count correlates with more negative sentiment (unexpected, needs further analysis)."

            rules.append(rule)

        return rules


# -------------------------- Case-Based Reasoner --------------------------
class CaseBasedReasoner:
    """
    Use past intervention cases to suggest effective strategies (Section5).
    Retrieves similar cases based on cognitive state and behavior patterns.
    """

    def __init__(self):
        # Mock case database (real implementation would use a database)
        self.case_database = [
            {
                "student_profile": {
                    "cognitive_states": {"knowledge": 0.4, "value": 0.3, "thinking": 0.5},
                    "behavior_patterns": ["low click frequency", "high pause count"],
                    "emotion_patterns": ["negative sentiment"]
                },
                "interventions": [
                    {"type": "feedback_session", "description": "Personalized feedback on engagement", "impact": 0.2},
                    {"type": "content_recommendation", "description": "Interactive quiz on key concepts",
                     "impact": 0.15}
                ],
                "outcome": {"knowledge": 0.6, "value": 0.4, "thinking": 0.55}
            },
            {
                "student_profile": {
                    "cognitive_states": {"knowledge": 0.6, "value": 0.2, "thinking": 0.5},
                    "behavior_patterns": ["medium click frequency", "low pause count"],
                    "emotion_patterns": ["neutral sentiment"]
                },
                "interventions": [
                    {"type": "content_recommendation", "description": "Case study on core values", "impact": 0.25},
                    {"type": "peer_collaboration", "description": "Pair with high value student", "impact": 0.1}
                ],
                "outcome": {"knowledge": 0.65, "value": 0.5, "thinking": 0.55}
            },
            {
                "student_profile": {
                    "cognitive_states": {"knowledge": 0.5, "value": 0.6, "thinking": 0.3},
                    "behavior_patterns": ["high click frequency", "medium pause count"],
                    "emotion_patterns": ["positive sentiment"]
                },
                "interventions": [
                    {"type": "activity_suggestion", "description": "Debate on critical thinking", "impact": 0.2},
                    {"type": "content_recommendation", "description": "Reading material on thinking skills",
                     "impact": 0.15}
                ],
                "outcome": {"knowledge": 0.55, "value": 0.65, "thinking": 0.5}
            }
        ]

    def find_similar_cases(self, student_profile: Dict[str, any], top_k: int = 2) -> List[Dict[str, any]]:
        """Find similar cases from the database based on student profile."""
        similar_cases = []
        for case in self.case_database:
            # Compute similarity score (mock implementation)
            similarity = 0.0
            # Similarity from cognitive states
            for state in ["knowledge", "value", "thinking"]:
                case_score = case["student_profile"]["cognitive_states"][state]
                student_score = student_profile["cognitive_states"][state]
                similarity += 1 - abs(case_score - student_score)
            # Similarity from behavior patterns
            case_behavior = set(case["student_profile"]["behavior_patterns"])
            student_behavior = set(student_profile["behavior_patterns"])
            similarity += len(case_behavior.intersection(student_behavior)) / len(case_behavior.union(student_behavior))
            # Similarity from emotion patterns
            case_emotion = set(case["student_profile"]["emotion_patterns"])
            student_emotion = set(student_profile["emotion_patterns"])
            similarity += len(case_emotion.intersection(student_emotion)) / len(case_emotion.union(student_emotion))
            # Normalize similarity
            similarity = similarity / (3 + 1 + 1)  # 3 cognitive states, 1 behavior,1 emotion
            similar_cases.append({"case": case, "similarity": similarity})

        # Sort by similarity and take top k
        similar_cases = sorted(similar_cases, key=lambda x: x["similarity"], reverse=True)[:top_k]
        return [case["case"] for case in similar_cases]

    def suggest_proven_strategies(self, student_profile: Dict[str, any]) -> List[Dict[str, str]]:
        """Suggest proven strategies from similar cases."""
        similar_cases = self.find_similar_cases(student_profile)
        proven_strategies = []
        for case in similar_cases:
            for intervention in case["interventions"]:
                if intervention["impact"] >= 0.15:  # Only include high-impact interventions
                    proven_strategies.append({
                        "type": intervention["type"],
                        "description": intervention["description"],
                        "proven_impact": intervention["impact"],
                        "source_case": "Similar student case"
                    })
        # Remove duplicates
        seen = set()
        unique_strategies = []
        for strategy in proven_strategies:
            key = (strategy["type"], strategy["description"])
            if key not in seen:
                seen.add(key)
                unique_strategies.append(strategy)
        return unique_strategies



