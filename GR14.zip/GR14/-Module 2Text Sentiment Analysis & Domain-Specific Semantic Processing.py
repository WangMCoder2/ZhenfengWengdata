import numpy as np
import pandas as pd
import re
from collections import defaultdict, Counter
import random
from typing import List, Dict, Tuple, Optional
from scipy.sparse import csr_matrix
from sklearn.preprocessing import normalize


# -------------------------- Domain Emotional Dictionary --------------------------
class MoralEducationEmotionalDictionary:
    """
    Domain-specific emotional dictionary for Moral Education courses (Section3.3).
    Stores positive/negative/neutral terms and computes sentiment scores.
    """

    def __init__(self):
        # Core domain terms (from article)
        self.positive_terms = [
            "Four Confidences", "humanity's shared future", "core socialist values",
            "national identity", "ideological progress", "moral cultivation",
            "rule of law", "social harmony", "collective responsibility",
            "patriotism", "dedication", "integrity", "friendship"
        ]
        self.negative_terms = [
            "ideological confusion", "moral decay", "selfishness", "dishonesty",
            "lawlessness", "social division", "patriotism deficit", "irresponsibility"
        ]
        self.neutral_terms = [
            "Marxist Principles", "Socialism with Chinese Characteristics",
            "legal basis", "situation and policy", "ideology and morality"
        ]

        # Sentiment mapping (1=positive, -1=negative, 0=neutral)
        self.term_sentiment = {}
        for term in self.positive_terms:
            self.term_sentiment[term] = 1.0
        for term in self.negative_terms:
            self.term_sentiment[term] = -1.0
        for term in self.neutral_terms:
            self.term_sentiment[term] = 0.0

        # Inverted index for fast term matching
        self.term_index = defaultdict(list)
        for term in self.positive_terms + self.negative_terms + self.neutral_terms:
            tokens = term.lower().split()
            for token in tokens:
                self.term_index[token].append(term)

    def get_sentiment_score(self, text: str) -> float:
        """Calculate sentiment score based on domain term frequency."""
        text_lower = text.lower()
        score = 0.0
        term_count = 0
        for term in self.term_sentiment:
            if term.lower() in text_lower:
                score += self.term_sentiment[term]
                term_count += 1
        return score / term_count if term_count > 0 else 0.0

    def extract_domain_terms(self, text: str) -> List[str]:
        """Extract domain-specific terms from text."""
        text_lower = text.lower()
        terms = []
        for term in self.term_sentiment:
            if term.lower() in text_lower:
                terms.append(term)
        return terms


# -------------------------- Text Preprocessor --------------------------
class TextPreprocessor:
    """
    Text preprocessing for Moral Education comments (Section3.3).
    Includes cleaning, tokenization, stopword removal, and domain term extraction.
    """

    def __init__(self, emotional_dict: MoralEducationEmotionalDictionary):
        self.emotional_dict = emotional_dict
        self.stopwords = set([
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
            "of", "with", "by", "from", "up", "down", "out", "about", "into",
            "over", "under", "again", "further", "then", "once", "here", "there",
            "when", "where", "why", "how", "all", "any", "both", "each", "few",
            "more", "most", "other", "some", "such", "no", "nor", "not", "only",
            "own", "same", "so", "than", "too", "very", "s", "t", "can", "will",
            "just", "don", "should", "now"
        ])
        self.punctuation_pattern = re.compile(r'[^\w\s]')

    def clean_text(self, text: str) -> str:
        """Clean text: remove punctuation, lowercase, strip whitespace."""
        text = self.punctuation_pattern.sub('', text)
        text = text.lower()
        text = text.strip()
        return text

    def tokenize(self, text: str) -> List[str]:
        """Tokenize text and remove stopwords."""
        clean_text = self.clean_text(text)
        tokens = clean_text.split()
        tokens = [token for token in tokens if token not in self.stopwords]
        return tokens

    def process_text(self, text: str) -> Tuple[List[str], List[str], float]:
        """Full preprocessing pipeline: returns tokens, domain terms, sentiment score."""
        tokens = self.tokenize(text)
        domain_terms = self.emotional_dict.extract_domain_terms(text)
        sentiment_score = self.emotional_dict.get_sentiment_score(text)
        return tokens, domain_terms, sentiment_score


# -------------------------- Hierarchical Transformer Encoder --------------------------
class HierarchicalTransformerEncoder:
    """
    Mock hierarchical Transformer encoder for semantic feature extraction (Section3.3).
    Simulates multi-head attention and feed-forward layers.
    """

    def __init__(self, vocab_size: int, embed_dim: int = 128, num_layers: int = 3, num_heads: int = 4):
        self.vocab_size = vocab_size
        self.embed_dim = embed_dim
        self.num_layers = num_layers
        self.num_heads = num_heads

        # Mock embedding matrix
        self.embedding = np.random.randn(vocab_size, embed_dim) * 0.01
        # Mock attention weights (per layer)
        self.attention_weights = [np.random.randn(num_heads, embed_dim, embed_dim) * 0.01 for _ in range(num_layers)]
        # Mock feed-forward weights (per layer)
        self.ffn_weights = [np.random.randn(embed_dim, embed_dim) * 0.01 for _ in range(num_layers)]

    def positional_encoding(self, seq_len: int) -> np.ndarray:
        """Generate positional encoding for sequence (Transformer-style)."""
        pos = np.arange(seq_len)[:, np.newaxis]
        i = np.arange(self.embed_dim)[np.newaxis, :]
        angle_rates = 1 / np.power(10000, (2 * (i // 2)) / self.embed_dim)
        angles = pos * angle_rates
        angles[:, 0::2] = np.sin(angles[:, 0::2])
        angles[:, 1::2] = np.cos(angles[:, 1::2])
        return angles

    def multi_head_attention(self, x: np.ndarray) -> np.ndarray:
        """Simulate multi-head attention layer."""
        seq_len, embed_dim = x.shape
        # Split into heads
        x_split = x.reshape(seq_len, self.num_heads, embed_dim // self.num_heads)
        # Apply attention to each head
        attn_output = []
        for head in range(self.num_heads):
            head_x = x_split[:, head, :]
            head_weight = self.attention_weights[0][head]
            head_out = head_x @ head_weight
            attn_output.append(head_out)
        # Concatenate heads
        return np.concatenate(attn_output, axis=1)

    def feed_forward(self, x: np.ndarray) -> np.ndarray:
        """Simulate feed-forward network layer."""
        return x @ self.ffn_weights[0] + np.random.randn(x.shape[0], self.embed_dim) * 0.01

    def encode(self, token_indices: List[int]) -> np.ndarray:
        """Encode token sequence into semantic embedding."""
        seq_len = len(token_indices)
        # Embedding lookup
        x = self.embedding[token_indices]
        # Add positional encoding
        x += self.positional_encoding(seq_len)
        # Pass through layers
        for _ in range(self.num_layers):
            # Attention layer
            attn_out = self.multi_head_attention(x)
            x = x + attn_out  # Residual connection
            x = np.tanh(x)
            # Feed-forward layer
            ffn_out = self.feed_forward(x)
            x = x + ffn_out  # Residual connection
            x = np.tanh(x)
        # Mean pooling for sequence embedding
        return np.mean(x, axis=0)


# -------------------------- Term Co-occurrence Graph Builder --------------------------
class TermCooccurrenceGraph:
    """
    Build term co-occurrence graph for GCN (Section3.3).
    Captures semantic relationships between domain terms.
    """

    def __init__(self, window_size: int = 5):
        self.window_size = window_size
        self.term_to_idx = {}
        self.idx_to_term = {}
        self.adj_matrix = None

    def build_vocab(self, terms_list: List[List[str]]) -> None:
        """Build vocabulary from list of term sequences."""
        all_terms = []
        for terms in terms_list:
            all_terms.extend(terms)
        unique_terms = list(set(all_terms))
        self.term_to_idx = {term: i for i, term in enumerate(unique_terms)}
        self.idx_to_term = {i: term for term, i in self.term_to_idx.items()}

    def build_adjacency_matrix(self, terms_list: List[List[str]]) -> np.ndarray:
        """Build normalized adjacency matrix from term co-occurrence."""
        if not self.term_to_idx:
            self.build_vocab(terms_list)
        vocab_size = len(self.term_to_idx)
        adj = np.zeros((vocab_size, vocab_size), dtype=np.float32)
        # Count co-occurrences
        for terms in terms_list:
            seq_len = len(terms)
            for i in range(seq_len):
                term_i = terms[i]
                if term_i not in self.term_to_idx:
                    continue
                idx_i = self.term_to_idx[term_i]
                # Window around i
                start = max(0, i - self.window_size)
                end = min(seq_len, i + self.window_size + 1)
                for j in range(start, end):
                    if i == j:
                        continue
                    term_j = terms[j]
                    if term_j not in self.term_to_idx:
                        continue
                    idx_j = self.term_to_idx[term_j]
                    adj[idx_i][idx_j] += 1.0
        # Normalize (row-wise L1 norm)
        adj = normalize(adj, norm='l1', axis=1)
        self.adj_matrix = adj
        return adj


# -------------------------- Graph Convolutional Network --------------------------
class GraphConvolutionalNetwork:
    """
    GCN for enhancing semantic features (Section3.3).
    Uses term co-occurrence graph to refine Transformer embeddings.
    """

    def __init__(self, input_dim: int, hidden_dim: int = 64, output_dim: int = 32, num_layers: int = 2):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_layers = num_layers

        # Mock weights and biases
        self.weights = [np.random.randn(input_dim, hidden_dim) * 0.01]
        for _ in range(num_layers - 1):
            self.weights.append(np.random.randn(hidden_dim, hidden_dim) * 0.01)
        self.weights.append(np.random.randn(hidden_dim, output_dim) * 0.01)

        self.biases = [np.random.randn(hidden_dim) * 0.01 for _ in range(num_layers)]
        self.biases.append(np.random.randn(output_dim) * 0.01)

    def graph_conv_layer(self, x: np.ndarray, adj: np.ndarray, weights: np.ndarray, bias: np.ndarray) -> np.ndarray:
        """Single GCN layer: x' = ReLU(adj @ x @ weights + bias)."""
        conv_out = adj @ x @ weights + bias
        return np.maximum(conv_out, 0)  # ReLU activation

    def forward(self, x: np.ndarray, adj: np.ndarray) -> np.ndarray:
        """Forward pass through GCN layers."""
        for i in range(self.num_layers + 1):
            x = self.graph_conv_layer(x, adj, self.weights[i], self.biases[i])
        return x


# -------------------------- Attention-based Sentiment Classifier --------------------------
class AttentionSentimentClassifier:
    """
    Attention-based sentiment classifier (Section3.3).
    Uses hierarchical attention to weight semantic features.
    """

    def __init__(self, input_dim: int, num_classes: int = 3):
        self.input_dim = input_dim
        self.num_classes = num_classes

        # Attention weights
        self.attention_weights = np.random.randn(input_dim, 1) * 0.01
        # Classification weights
        self.classifier_weights = np.random.randn(input_dim, num_classes) * 0.01
        self.classifier_bias = np.random.randn(num_classes) * 0.01

    def compute_attention(self, x: np.ndarray) -> np.ndarray:
        """Compute attention weights for input features."""
        attn_scores = x @ self.attention_weights
        attn_scores = np.exp(attn_scores) / np.sum(np.exp(attn_scores), axis=0)
        return attn_scores

    def classify(self, x: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Classify sentiment: returns probabilities and attention weights."""
        attn_weights = self.compute_attention(x)
        weighted_x = x * attn_weights
        logits = weighted_x @ self.classifier_weights + self.classifier_bias
        probabilities = np.exp(logits) / np.sum(np.exp(logits), axis=1, keepdims=True)
        return probabilities, attn_weights


# -------------------------- End-to-End Pipeline --------------------------
class TextProcessingPipeline:
    """
    End-to-end pipeline for text sentiment analysis (Section3.3).
    Combines preprocessing, encoding, GCN, and classification.
    """

    def __init__(self):
        # Initialize components
        self.emotional_dict = MoralEducationEmotionalDictionary()
        self.preprocessor = TextPreprocessor(self.emotional_dict)
        # Vocab (built from domain terms)
        self.vocab = {'<PAD>': 0, '<UNK>': 1}
        for term in self.emotional_dict.term_sentiment:
            tokens = self.preprocessor.tokenize(term)
            for token in tokens:
                if token not in self.vocab:
                    self.vocab[token] = len(self.vocab)
        # Transformer encoder
        self.transformer = HierarchicalTransformerEncoder(vocab_size=len(self.vocab), embed_dim=128)
        # Term graph builder
        self.graph_builder = TermCooccurrenceGraph(window_size=5)
        # GCN
        self.gcn = GraphConvolutionalNetwork(input_dim=128, hidden_dim=64, output_dim=32)
        # Sentiment classifier
        self.classifier = AttentionSentimentClassifier(input_dim=32)

    def token_to_idx(self, tokens: List[str]) -> List[int]:
        """Convert tokens to indices using vocab."""
        return [self.vocab.get(token, self.vocab['<UNK>']) for token in tokens]

    def build_graph(self, comments: List[str]) -> None:
        """Build term co-occurrence graph from comments."""
        terms_list = []
        for comment in comments:
            _, domain_terms, _ = self.preprocessor.process_text(comment)
            terms_list.append(domain_terms)
        self.graph_builder.build_adjacency_matrix(terms_list)

    def process_comment(self, comment: str) -> Tuple[np.ndarray, float, List[str], np.ndarray]:
        """Process single comment: returns sentiment prob, score, domain terms, attention weights."""
        # Preprocess
        tokens, domain_terms, sentiment_score = self.preprocessor.process_text(comment)
        token_indices = self.token_to_idx(tokens)
        if not token_indices:
            return np.zeros(self.classifier.num_classes), 0.0, [], np.zeros(0)
        # Transformer encode
        transformer_emb = self.transformer.encode(token_indices)
        # GCN refine
        if not domain_terms or not self.graph_builder.adj_matrix:
            gcn_emb = transformer_emb
        else:
            # Mock term embedding (average of token embeddings)
            term_emb = transformer_emb.reshape(len(tokens), -1).mean(axis=0).reshape(1, -1)
            gcn_emb = self.gcn.forward(term_emb, self.graph_builder.adj_matrix)
        # Classify
        prob, attn = self.classifier.classify(gcn_emb)
        return prob[0], sentiment_score, domain_terms, attn



