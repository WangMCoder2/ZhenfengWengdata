import numpy as np
import pandas as pd
import time
import json
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timedelta
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn


# -------------------------- System Integrator --------------------------
class SystemIntegrator:
    """
    Integrates all modules (1-5) into a unified pipeline for end-to-end processing.
    Combines behavior analysis, text processing, fusion, evaluation, and intervention.
    """

    def __init__(self,
                 behavior_processor: object,
                 text_processor: object,
                 fusion_pipeline: object,
                 evaluator: object,
                 portrait_generator: object,
                 intervention_engine: object,
                 evolution_tracker: object):
        self.behavior_processor = behavior_processor
        self.text_processor = text_processor
        self.fusion_pipeline = fusion_pipeline
        self.evaluator = evaluator
        self.portrait_generator = portrait_generator
        self.intervention_engine = intervention_engine
        self.evolution_tracker = evolution_tracker

    def process_student_data(self,
                             student_id: str,
                             behavior_logs: List[Dict],
                             text_comments: List[str]) -> Dict[str, any]:
        """
        Process student data end-to-end: from raw logs/comments to cognitive portrait and interventions.
        Args:
            student_id: Unique student ID
            behavior_logs: List of raw behavior logs (from LMS, etc.)
            text_comments: List of student comments (from forums, etc.)
        Returns:
            Full processing result including cognitive states, portrait, interventions, and evolution.
        """
        # Step1: Process behavior logs (Module1)
        behavior_features = self.behavior_processor.process_logs(behavior_logs)

        # Step2: Process text comments (Module2)
        text_features = self.text_processor.process_comments(text_comments)

        # Step3: Multi-modal fusion (Module3)
        cognitive_states = self.fusion_pipeline.process_modalities(behavior_features, text_features)

        # Step4: Evaluate model performance (Module4)
        evaluation_metrics = self.evaluator.evaluate(cognitive_states)

        # Step5: Generate cognitive portrait (Module5)
        shap_values = self.evaluator.compute_shap_values()
        behavior_emotion_patterns = self.evaluator.compute_correlations()
        cognitive_portrait = self.portrait_generator.generate_portrait(
            student_id=student_id,
            cognitive_states=cognitive_states,
            behavior_features=behavior_features,
            text_features=text_features,
            shap_values=shap_values,
            behavior_emotion_patterns=behavior_emotion_patterns
        )

        # Step6: Generate intervention strategies (Module5)
        intervention_strategies = self.intervention_engine.generate_strategies(cognitive_portrait)

        # Step7: Track cognitive evolution (Module6)
        self.evolution_tracker.track_evolution(student_id, cognitive_states)
        evolution_data = self.evolution_tracker.get_evolution_data(student_id)

        # Compile result
        result = {
            "student_id": student_id,
            "timestamp": datetime.now().isoformat(),
            "cognitive_states": cognitive_states,
            "evaluation_metrics": evaluation_metrics,
            "cognitive_portrait": cognitive_portrait,
            "intervention_strategies": intervention_strategies,
            "cognitive_evolution": evolution_data
        }

        return result


# -------------------------- Cognitive Evolution Tracker --------------------------
class CognitiveEvolutionTracker:
    """
    Tracks cognitive state changes over time (Section6 future work: cognitive evolution modeling).
    Stores historical data and generates evolution curves.
    """

    def __init__(self, storage_path: str = "evolution_data.json"):
        self.storage_path = storage_path
        self.evolution_data = self._load_data()

    def _load_data(self) -> Dict[str, List[Dict]]:
        """Load historical evolution data from storage."""
        try:
            with open(self.storage_path, "r") as f:
                return json.load(f)
        except FileNotFoundError:
            return {}

    def _save_data(self) -> None:
        """Save evolution data to storage."""
        with open(self.storage_path, "w") as f:
            json.dump(self.evolution_data, f, indent=2)

    def track_evolution(self, student_id: str, cognitive_states: Dict[str, float]) -> None:
        """Track cognitive state evolution for a student."""
        if student_id not in self.evolution_data:
            self.evolution_data[student_id] = []

        # Add current cognitive state to evolution data
        self.evolution_data[student_id].append({
            "timestamp": datetime.now().isoformat(),
            "cognitive_states": cognitive_states
        })

        self._save_data()

    def get_evolution_data(self, student_id: str) -> List[Dict]:
        """Get historical evolution data for a student."""
        return self.evolution_data.get(student_id, [])

    def generate_evolution_curve(self, student_id: str, state: str) -> Dict[str, List]:
        """Generate evolution curve for a specific cognitive state."""
        evolution_data = self.get_evolution_data(student_id)
        if not evolution_data:
            return {"timestamps": [], "values": []}

        timestamps = []
        values = []
        for entry in evolution_data:
            timestamps.append(entry["timestamp"])
            values.append(entry["cognitive_states"][state])

        return {
            "state": state,
            "timestamps": timestamps,
            "values": values,
            "trend": self._compute_trend(values)
        }

    def _compute_trend(self, values: List[float]) -> str:
        """Compute trend (increasing, decreasing, stable) from value sequence."""
        if len(values) < 2:
            return "stable"

        # Compute linear regression slope
        x = np.arange(len(values))
        y = np.array(values)
        slope = np.polyfit(x, y, 1)[0]

        if slope > 0.01:
            return "increasing"
        elif slope < -0.01:
            return "decreasing"
        else:
            return "stable"


# -------------------------- Real-Time Deployment API --------------------------
class APIModel(BaseModel):
    """Pydantic model for API request/response."""
    student_id: str
    behavior_logs: List[Dict]
    text_comments: List[str]


class DeploymentAPI:
    """
    Real-time deployment API using FastAPI (Section6: system deployment).
    Exposes endpoints for processing student data and getting results.
    """

    def __init__(self, system_integrator: SystemIntegrator):
        self.app = FastAPI(title="Moral Education Cognitive Evaluation API", version="1.0")
        self.system_integrator = system_integrator

        # Define API endpoints
        @self.app.post("/process_student")
        async def process_student(data: APIModel):
            try:
                result = self.system_integrator.process_student_data(
                    student_id=data.student_id,
                    behavior_logs=data.behavior_logs,
                    text_comments=data.text_comments
                )
                return {"status": "success", "data": result}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @self.app.get("/get_evolution/{student_id}/{state}")
        async def get_evolution(student_id: str, state: str):
            try:
                evolution_curve = self.system_integrator.evolution_tracker.generate_evolution_curve(student_id, state)
                return {"status": "success", "data": evolution_curve}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """Run the API server."""
        uvicorn.run(self.app, host=host, port=port)


# -------------------------- Dynamic Strategy Optimizer --------------------------
class DynamicStrategyOptimizer:
    """
    Optimizes intervention strategies dynamically based on cognitive evolution (Section6 future work).
    Adjusts strategies based on whether previous strategies improved cognitive states.
    """

    def __init__(self, intervention_engine: object, evolution_tracker: object):
        self.intervention_engine = intervention_engine
        self.evolution_tracker = evolution_tracker
        self.strategy_history = {}

    def optimize_strategies(self, student_id: str, previous_strategies: List[Dict]) -> List[Dict]:
        """
        Optimize strategies based on previous impact and cognitive evolution.
        Args:
            student_id: Unique student ID
            previous_strategies: List of previously applied strategies
        Returns:
            Optimized list of strategies.
        """
        # Get cognitive evolution data
        evolution_data = self.evolution_tracker.get_evolution_data(student_id)
        if len(evolution_data) < 2:
            return previous_strategies

        # Compute impact of previous strategies
        previous_states = evolution_data[-2]["cognitive_states"]
        current_states = evolution_data[-1]["cognitive_states"]
        impact = {state: current_states[state] - previous_states[state] for state in current_states}

        # Optimize strategies based on impact
        optimized_strategies = []
        for strategy in previous_strategies:
            state_affected = self._get_state_affected(strategy)
            if state_affected:
                if impact[state_affected] > 0.05:
                    # Strategy worked: keep or enhance
                    optimized_strategy = self._enhance_strategy(strategy)
                    optimized_strategies.append(optimized_strategy)
                else:
                    # Strategy didn't work: replace
                    replacement_strategy = self._replace_strategy(strategy)
                    optimized_strategies.append(replacement_strategy)
            else:
                # Keep strategy if no clear state affected
                optimized_strategies.append(strategy)

        # Add new strategies if needed
        for state in current_states:
            if current_states[state] < 0.5 and state not in [self._get_state_affected(s) for s in optimized_strategies]:
                new_strategy = self.intervention_engine.generate_strategy_for_state(state)
                optimized_strategies.append(new_strategy)

        return optimized_strategies

    def _get_state_affected(self, strategy: Dict) -> Optional[str]:
        """Determine which cognitive state a strategy affects."""
        description = strategy["description"].lower()
        if "knowledge" in description:
            return "knowledge"
        elif "value" in description:
            return "value"
        elif "thinking" in description:
            return "thinking"
        else:
            return None

    def _enhance_strategy(self, strategy: Dict) -> Dict:
        """Enhance a strategy that worked."""
        strategy["description"] += " (enhanced: previous impact was positive)"
        strategy["priority"] = "High"
        return strategy

    def _replace_strategy(self, strategy: Dict) -> Dict:
        """Replace a strategy that didn't work."""
        state_affected = self._get_state_affected(strategy)
        if state_affected:
            new_strategy = self.intervention_engine.generate_strategy_for_state(state_affected)
            new_strategy["description"] += " (replaced: previous strategy had low impact)"
            return new_strategy
        else:
            return strategy


# -------------------------- Report Generator --------------------------
class ReportGenerator:
    """
    Generates comprehensive reports for teachers/administrators (Section6: system application).
    Creates PDF/HTML reports with cognitive portraits, interventions, and evolution curves.
    """

    def __init__(self):
        self.report_template = """
        <html>
        <head>
            <title>Cognitive Evaluation Report: {student_id}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .section {{ margin-bottom: 30px; }}
                .section-title {{ font-size: 18px; font-weight: bold; margin-bottom:10px; border-bottom:1px solid #ccc; }}
                .portrait-item {{ margin-bottom:5px; }}
                .strategy {{ margin-bottom:5px; padding:5px; border-left:3px solid #4CAF50; }}
                .evolution-curve {{ margin-top:10px; }}
            </style>
        </head>
        <body>
            <h1>Cognitive Evaluation Report: {student_id}</h1>
            <p>Generated on: {timestamp}</p>

            <div class="section">
                <div class="section-title">Cognitive State Summary</div>
                {cognitive_state_summary}
            </div>

            <div class="section">
                <div class="section-title">Cognitive Portrait</div>
                {cognitive_portrait}
            </div>

            <div class="section">
                <div class="section-title">Intervention Strategies</div>
                {intervention_strategies}
            </div>

            <div class="section">
                <div class="section-title">Cognitive Evolution</div>
                {evolution_curves}
            </div>
        </body>
        </html>
        """

    def generate_html_report(self, processing_result: Dict) -> str:
        """Generate HTML report from processing result."""
        # Format cognitive state summary
        cognitive_state_summary = "<ul>"
        for state, value in processing_result["cognitive_states"].items():
            cognitive_state_summary += f"<li>{state.replace('_', ' ').title()}: {value:.2f}</li>"
        cognitive_state_summary += "</ul>"

        # Format cognitive portrait
        cognitive_portrait = "<div class='portrait-item'><strong>Key Strengths:</strong> {}</div>".format(
            processing_result["cognitive_portrait"]["Key Strengths"].replace("\n", "<br>")
        )
        cognitive_portrait += "<div class='portrait-item'><strong>Areas for Improvement:</strong> {}</div>".format(
            processing_result["cognitive_portrait"]["Areas for Improvement"].replace("\n", "<br>")
        )

        # Format intervention strategies
        intervention_strategies = ""
        for strategy in processing_result["intervention_strategies"]:
            intervention_strategies += f"<div class='strategy'><strong>{strategy['type']}:</strong> {strategy['description']} (Priority: {strategy['priority']})</div>"

        # Format evolution curves
        evolution_curves = ""
        for state in processing_result["cognitive_states"]:
            evolution_curve = processing_result["cognitive_evolution"][state]
            evolution_curves += f"<div class='evolution-curve'><strong>{state.replace('_', ' ').title()}:</strong> Trend: {evolution_curve['trend']}</div>"

        # Fill template
        report_html = self.report_template.format(
            student_id=processing_result["student_id"],
            timestamp=processing_result["timestamp"],
            cognitive_state_summary=cognitive_state_summary,
            cognitive_portrait=cognitive_portrait,
            intervention_strategies=intervention_strategies,
            evolution_curves=evolution_curves
        )

        return report_html

    def save_report_to_file(self, report_html: str, file_path: str):
        """Save HTML report to file."""
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(report_html)



