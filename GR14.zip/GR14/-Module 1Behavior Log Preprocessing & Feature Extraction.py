import pandas as pd
import numpy as np
from scipy.stats import entropy
from scipy.signal import correlate
from sklearn.cluster import SpectralClustering
from sklearn.preprocessing import StandardScaler
from datetime import datetime, timedelta
import random
from typing import List, Tuple, Dict, Optional


# -------------------------- Data Structure Definition --------------------------
class BehaviorLogEntry:
    """
    Represents a single behavior log entry with 28-dimensional features (as per Section3.2).
    Models the raw input data for adaptive segmentation and feature extraction.
    """

    def __init__(self, timestamp: str, log_type: str, click_count: int, time_spent: float,
                 pause_count: int, download_count: int, quiz_attempts: int, correct_ratio: float,
                 resource_access: int, task_completion: float, session_duration: float,
                 session_interval: float, response_delay: float, path_entropy: float,
                 video_watch_duration: float, discussion_participation: float, feature_16: float,
                 feature_17: float, feature_18: float, feature_19: float, feature_20: float,
                 feature_21: float, feature_22: float, feature_23: float, feature_24: float,
                 feature_25: float, feature_26: float, feature_27: float, feature_28: float):
        """
        Initialize a behavior log entry with all 28 features and metadata.
        Args:
            timestamp: ISO format string (YYYY-MM-DD HH:MM:SS)
            log_type: Behavior category (click/pause/download/quiz/resource_access)
            click_count: Number of clicks (feature 1)
            time_spent: Time spent on task (minutes, feature2)
            pause_count: Number of pauses (feature3)
            download_count: Number of downloads (feature4)
            quiz_attempts: Quiz attempts (feature5)
            correct_ratio: Correct answer ratio (feature6)
            resource_access: Resource access count (feature7)
            task_completion: Task completion rate (feature8)
            session_duration: Session duration (minutes, feature9)
            session_interval: Interval since last session (hours, feature10)
            response_delay: Response delay (seconds, feature11)
            path_entropy: Path entropy (feature12)
            video_watch_duration: Video watch time (minutes, feature13)
            discussion_participation: Discussion participation rate (feature14)
            feature_16-28: Additional 13 features to reach 28 dimensions
        """
        self.timestamp = datetime.fromisoformat(timestamp)
        self.log_type = log_type
        self.features = {
            'click_count': click_count,
            'time_spent': time_spent,
            'pause_count': pause_count,
            'download_count': download_count,
            'quiz_attempts': quiz_attempts,
            'correct_ratio': correct_ratio,
            'resource_access': resource_access,
            'task_completion': task_completion,
            'session_duration': session_duration,
            'session_interval': session_interval,
            'response_delay': response_delay,
            'path_entropy': path_entropy,
            'video_watch_duration': video_watch_duration,
            'discussion_participation': discussion_participation,
            'feature_16': feature_16,
            'feature_17': feature_17,
            'feature_18': feature_18,
            'feature_19': feature_19,
            'feature_20': feature_20,
            'feature_21': feature_21,
            'feature_22': feature_22,
            'feature_23': feature_23,
            'feature_24': feature_24,
            'feature_25': feature_25,
            'feature_26': feature_26,
            'feature_27': feature_27,
            'feature_28': feature_28
        }
        assert len(self.features) == 28, "28-dimensional features required per log entry"

    def to_dict(self) -> Dict:
        """Serialize log entry to dictionary."""
        return {
            'timestamp': self.timestamp.isoformat(),
            'log_type': self.log_type,
            **self.features
        }

    @staticmethod
    def from_dict(data: Dict) -> 'BehaviorLogEntry':
        """Deserialize log entry from dictionary."""
        return BehaviorLogEntry(
            timestamp=data['timestamp'],
            log_type=data['log_type'],
            click_count=data['click_count'],
            time_spent=data['time_spent'],
            pause_count=data['pause_count'],
            download_count=data['download_count'],
            quiz_attempts=data['quiz_attempts'],
            correct_ratio=data['correct_ratio'],
            resource_access=data['resource_access'],
            task_completion=data['task_completion'],
            session_duration=data['session_duration'],
            session_interval=data['session_interval'],
            response_delay=data['response_delay'],
            path_entropy=data['path_entropy'],
            video_watch_duration=data['video_watch_duration'],
            discussion_participation=data['discussion_participation'],
            feature_16=data['feature_16'],
            feature_17=data['feature_17'],
            feature_18=data['feature_18'],
            feature_19=data['feature_19'],
            feature_20=data['feature_20'],
            feature_21=data['feature_21'],
            feature_22=data['feature_22'],
            feature_23=data['feature_23'],
            feature_24=data['feature_24'],
            feature_25=data['feature_25'],
            feature_26=data['feature_26'],
            feature_27=data['feature_27'],
            feature_28=data['feature_28']
        )


# -------------------------- Adaptive Dynamic Window Segmentation --------------------------
def adaptive_dynamic_window_segmentation(
        logs: List[BehaviorLogEntry],
        base_window_size: int = 10,
        max_window_size: int = 20,
        min_window_size: int = 5,
        std_threshold: float = 0.15
) -> List[List[BehaviorLogEntry]]:
    """
    Segment behavior logs into adaptive windows based on time_spent fluctuation (Section3.2).
    - Splits windows when time_spent std exceeds threshold (high fluctuation)
    - Expands windows when std is low (stable behavior)

    Args:
        logs: Sorted list of BehaviorLogEntry (ascending timestamp)
        base_window_size: Initial window size
        max_window_size: Maximum allowed window size
        min_window_size: Minimum allowed window size
        std_threshold: Std deviation threshold for window split

    Returns:
        List of window segments (each segment is a list of log entries)
    """
    if not logs:
        raise ValueError("Empty logs list")
    for i in range(1, len(logs)):
        if logs[i].timestamp < logs[i - 1].timestamp:
            raise ValueError("Logs must be sorted by timestamp")

    segments = []
    current_window = []
    current_window_size = base_window_size

    for log in logs:
        current_window.append(log)
        if len(current_window) >= current_window_size:
            time_spent_vals = [e.features['time_spent'] for e in current_window]
            std_dev = np.std(time_spent_vals)

            if std_dev > std_threshold:
                segments.append(current_window.copy())
                current_window = []
                current_window_size = min_window_size
            else:
                current_window_size = min(current_window_size + 1, max_window_size)

    if current_window:
        segments.append(current_window)
    return segments


# -------------------------- Behavioral Feature Extraction --------------------------
def compute_shannon_entropy(window: List[BehaviorLogEntry]) -> float:
    """
    Compute cognitive engagement using Shannon entropy of log type distribution (Section3.2).
    Formula: H = -sum(p_i * log2(p_i)), where p_i = frequency of log type i.
    """
    if not window:
        return 0.0
    log_type_counts = {}
    total = len(window)
    for e in window:
        log_type_counts[e.log_type] = log_type_counts.get(e.log_type, 0) + 1
    probs = [count / total for count in log_type_counts.values()]
    return entropy(probs, base=2)


def compute_auto_correlation(window: List[BehaviorLogEntry], lag: int = 1) -> float:
    """
    Compute learning stability using auto-correlation of time_spent (Section3.2).
    Measures temporal consistency of behavior.
    """
    if len(window) <= lag:
        return0
        .0
    time_spent_seq = np.array([e.features['time_spent'] for e in window])
    corr = correlate(time_spent_seq, time_spent_seq, mode='full')[len(time_spent_seq) - 1 + lag]
    norm = np.sum(time_spent_seq ** 2)
    return corr / norm if norm != 0
    else0
    .0


def compute_spectral_clustering(segments: List[List[BehaviorLogEntry]], n_clusters: int = 5) -> List[int]:
    """
    Cluster segments using spectral clustering to identify behavior patterns (Section3.2).
    Each segment is represented by mean values of its 28 features.
    """
    if not segments:
        return []
    segment_features = []
    for seg in segments:
        agg_features = {k: np.mean([e.features[k] for e in seg]) for k in seg[0].features.keys()}
        segment_features.append([agg_features[k] for k in sorted(agg_features.keys())])

    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(segment_features)
    spectral = SpectralClustering(n_clusters=n_clusters, affinity='nearest_neighbors', random_state=42)
    return spectral.fit_predict(scaled_features)


def extract_segment_features(segment: List[BehaviorLogEntry]) -> Dict[str, float]:
    """
    Extract aggregated and derived features for a segment (Section3.2).
    Combines raw feature means with derived metrics (entropy, auto-correlation).
    """
    if not segment:
        return {}
    # Aggregate raw features
    raw_agg = {f'raw_{k}': np.mean([e.features[k] for e in segment]) for k in segment[0].features.keys()}
    # Derived features
    derived = {
        'cognitive_engagement': compute_shannon_entropy(segment),
        'learning_stability': compute_auto_correlation(segment),
        'segment_duration_min': (segment[-1].timestamp - segment[0].timestamp).total_seconds() / 60,
        'segment_entry_count': len(segment)
    }
    return {**raw_agg, **derived}


# -------------------------- Pipeline Execution --------------------------
def behavior_log_pipeline(logs: List[BehaviorLogEntry]) -> Tuple[List[Dict], List[int]]:
    """
    End-to-end pipeline for behavior log processing:
    1. Adaptive window segmentation
    2. Feature extraction per segment
    3. Spectral clustering of segments

    Returns:
        Tuple of (segment features list, cluster labels list)
    """
    segments = adaptive_dynamic_window_segmentation(logs)
    segment_features = [extract_segment_features(s) for s in segments]
    cluster_labels = compute_spectral_clustering(segments)
    return segment_features, cluster_labels


# -------------------------- Example Usage --------------------------
def generate_sample_logs(num_entries: int = 200) -> List[BehaviorLogEntry]:
    """Generate sample behavior logs for testing."""
    logs = []
    start_time = datetime(2023, 9, 1, 8, 0, 0)
    log_types = ['click', 'pause', 'download', 'quiz', 'resource_access']

    for i in range(num_entries):
        timestamp = (start_time + timedelta(minutes=random.randint(5, 15))).isoformat()
        log_type = random.choice(log_types)
        # Generate plausible feature values
        log_entry = BehaviorLogEntry(
            timestamp=timestamp,
            log_type=log_type,
            click_count=random.randint(1, 20),
            time_spent=round(random.uniform(1, 30), 2),
            pause_count=random.randint(0, 5),
            download_count=random.randint(0, 3),
            quiz_attempts=random.randint(1, 3),
            correct_ratio=round(random.uniform(0.5, 1.0), 2),
            resource_access=random.randint(0, 5),
            task_completion=round(random.uniform(0.6, 1.0), 2),
            session_duration=round(random.uniform(10, 60), 2),
            session_interval=round(random.uniform(1, 24), 2),
            response_delay=round(random.uniform(0, 10), 2),
            path_entropy=round(random.uniform(0.1, 0.9), 2),
            video_watch_duration=round(random.uniform(5, 20), 2),
            discussion_participation=round(random.uniform(0.2, 0.8), 2),
            feature_16=round(random.uniform(0, 1), 2),
            feature_17=round(random.uniform(0, 1), 2),
            feature_18=round(random.uniform(0, 1), 2),
            feature_19=round(random.uniform(0, 1), 2),
            feature_20=round(random.uniform(0, 1), 2),
            feature_21=round(random.uniform(0, 1), 2),
            feature_22=round(random.uniform(0, 1), 2),
            feature_23=round(random.uniform(0, 1), 2),
            feature_24=round(random.uniform(0, 1), 2),
            feature_25=round(random.uniform(0, 1), 2),
            feature_26=round(random.uniform(0, 1), 2),
            feature_27=round(random.uniform(0, 1), 2),
            feature_28=round(random.uniform(0, 1), 2)
        )
        logs.append(log_entry)
        start_time = datetime.fromisoformat(timestamp)
    return logs


if __name__ == "__main__":
    print("=== Module1: Behavior Log Preprocessing & Feature Extraction ===")
    sample_logs = generate_sample_logs(200)
    print(f"Generated {len(sample_logs)} sample logs")

    segments, cluster_labels = behavior_log_pipeline(sample_logs)
    print(f"Segmented into {len(segments)} windows | Cluster labels: {cluster_labels[:10]}...")

    if segments:
        first_segment = segments[0]
        print("\nFirst segment features:")
        for k, v in sorted(first_segment.items())[:10]:
            print(f"  {k}: {v:.4f}")
    print("\nModule1 Execution Complete")
